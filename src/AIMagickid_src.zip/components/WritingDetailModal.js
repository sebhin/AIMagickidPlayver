import React from 'react';
import '../styles/WritingDetailModal.scss';
import RenderTextWithBreaks from './RenderTextWithBreaks';

const WritingDetailModal = ({ text, onClose }) => {
    return (
        <>
            <section className="writing-detail-modal">
                <div className="inner">
                <figure>
                        <img
                            src={'/images/paper-wide.svg'}
                            alt="writing-detail-paper"
                        />
                    </figure>
                    <div className="writing-conts">
                        <h3 className="writing-tit">{text.title}</h3>
                        <div className="writing-all">
                            <RenderTextWithBreaks text={text.creation} />
                        </div>
                    </div>
                    <span
                        className="btn close-btn"
                        onClick={onClose}
                    >
                        확인
                    </span>
                </div>
            </section>
        </>
    );
};

export default WritingDetailModal;
