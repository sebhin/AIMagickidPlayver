import React, { useEffect, useState } from 'react';
import '../styles/WorkTabs.scss';
import WideViewModal from '../components/WideViewModal';
import WritingDetailModal from './WritingDetailModal';
import DrawingList from './DrawingList';
import WritingList from './WritingList';
import { getUserCreationList, getSchoolCreationList } from '../api/workAPI'
import ContestConts from './ContestConts';

const WorkTabs = ({ page_type }) => {
    const USER_ID = localStorage.getItem('userID');
    const USER_NAME = localStorage.getItem('userName');
    const story4uURL = process.env.REACT_APP_STORY4U_URL
    const story4uPort = process.env.REACT_APP_STORY4U_PORT
    
    const [activeTab, setActiveTab] = useState('drawing'); // tab active
    const [modalOpen, setModalOpen] = useState(false); // 모달 상태
    const [selectedImage, setSelectedImage] = useState(null); // 선택된 이미지
    const [selectedWriting, setSelectedWriting] = useState(null); // 선택된 글
    const [randomImage, setRandomImage] = useState(''); // 랜덤 이미지
    const [writingModalOpen, setWritingModalOpen] = useState(false); // 글 상세 모달 상태

    const [creationList, setCreationList] = useState([]); // tab active
    const [selectedOption, setSelectedOption] = useState('최신순');

    const handleSelectChange = (event) => {
        setSelectedOption(event.target.value);
    };

    const openWritingModal = () => {
        setWritingModalOpen(true);
    };

    // writing-paper 랜덤 이미지 리스트
    const imageList = [
        '/images/poem-paper-blue.svg',
        '/images/poem-paper-red.svg',
        '/images/poem-paper-green.svg',
        '/images/poem-paper-yellow.svg',
    ];

    
    // 랜덤 이미지 생성
    const selectRandomImage = () => {
        const randomIndex = Math.floor(Math.random() * imageList.length);
        setRandomImage(imageList[randomIndex]);
    };

    const callCreationListAPI = async () => {
        let result;
        if(page_type==="my"){
            result = await getUserCreationList(USER_ID, activeTab)
        }
        else if(page_type==="school"){
            result = await getSchoolCreationList(USER_ID, activeTab)
            
        }
        
        if(result.success){
            console.log(result.data)
            setCreationList(result.data)
        }
        else{
            console.error(result.data)
        }
    };

    // 컴포넌트 마운트 시 랜덤 이미지 선택
    useEffect(() => {
        if(activeTab==="storybook"){
            const params = { userID: USER_ID, userName: USER_NAME }
            const query = new URLSearchParams(params).toString();
            window.open(`${story4uURL}:${story4uPort}?${query}`, '_blank', 'noopener,noreferrer');
        }
        selectRandomImage();
        callCreationListAPI();
        
    }, [activeTab]);

    useEffect(() => {
        // 새로운 정렬된 리스트를 계산
        const sortedList = [...creationList].sort((a, b) => {
          return selectedOption === '최신순'
            ? b.creation_id - a.creation_id
            : a.creation_id - b.creation_id;
        });
      
        // 정렬된 리스트로 상태 업데이트
        setCreationList(sortedList);
      }, [selectedOption]);

    // 선택된 탭 active
    const handleTabClick = (tab) => {
        setActiveTab(tab);
    };

    // 모달 열기
    const openModal = (result) => {
        if(activeTab==="writing"){
            setSelectedWriting(result);
            setWritingModalOpen(true);
        }
        else if(activeTab==="drawing"){
            setSelectedImage(result);
            setModalOpen(true);
        }
    };

    return (
        <>
            <div className="toggle-btn-list">
                <button
                    onClick={() => {
                        handleTabClick('drawing');
                    }}
                    className={`btn toggle-btn ${
                        activeTab === 'drawing' ? 'active' : ''
                    }`}
                >
                    그림
                </button>
                <button
                    onClick={() => {
                        handleTabClick('writing');
                    }}
                    className={`btn toggle-btn ${
                        activeTab === 'writing' ? 'active' : ''
                    }`}
                >
                    글
                </button>
                <button
                    onClick={() => {
                        handleTabClick('storybook');
                    }}
                    className={`btn toggle-btn ${
                        activeTab === 'storybook' ? 'active' : ''
                    }`}
                >
                    그림동화
                </button>
            </div>
            <select className="selectbox" value={selectedOption} onChange={handleSelectChange}>
                <option value="최신순">최신순</option>
                <option value="오래된 순">오래된 순</option>
            </select>
            <div className="tab-contents">
                {/* {activeTab === 'drawing' && (
                    <ul className="drawing-list">
                        {creationList.map((creation, index) => (
                            <li key={index}>
                                <img
                                    src={creation.creation}
                                    alt={`작품 ${index + 1}`}
                                    onClick={() => openModal(creation.creation)}
                                />
                            </li>
                        ))}
                    </ul>
                )}
                {activeTab === 'writing' && (
                    <ul className="writing-list">
                        {creationList.map((creation, index) => (
                            <li
                                key={index}
                                className="writing"
                                onClick={() => openModal({
                                    title: creation.creation_title,
                                    creation: creation.creation
                                })}
                            >
                                <figure className="paper">
                                    <img
                                        src={randomImage}
                                        alt="writing-paper"
                                    />
                                </figure>
                                <div className="writing-txt">
                                    <h2 className="writing-tit">
                                        {creation.creation_title}
                                    </h2>
                                    <p className="peom-create-date">{creation.creation_date}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                )} */}
                {activeTab === 'drawing' && (
                    (page_type === "my" && (
                        <DrawingList
                            creationList={creationList}
                            openModal={openModal}
                        />
                    )) ||
                    (page_type === "school" && (
                        <ContestConts
                            creationList={creationList}
                            openModal={openModal}
                        />
                    ))
                )}
                {activeTab === 'writing' && (
                    <WritingList
                        creationList={creationList}
                        randomImage={randomImage}
                        openModal={openModal}
                        page_type={page_type}
                    />
                )}
                {activeTab === 'storybook' && <div>스토리포유 링크로 이동</div>}
            </div>
            {modalOpen && (
                <WideViewModal
                    image={selectedImage}
                    onClose={() => setModalOpen(false)}
                />
            )}
            {writingModalOpen && (
                <WritingDetailModal text={selectedWriting} onClose={() => setWritingModalOpen(false)} />
            )}
        </>
    );
};

export default WorkTabs;
