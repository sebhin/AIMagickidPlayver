import React, { useState } from 'react';
import '../styles/Result.scss';
import ViewAllModal from './ViewAllModal'; 
import RenderTextWithBreaks from './RenderTextWithBreaks';

const Result = ({type, result, resultList, onResult}) => {
    const [selectedContent, setSelectedContent] = useState('');
    const [showViewAllModal, setShowViewAllModal] = useState(false);

    console.log("Result compo=> ",resultList)
    const result_title = {
        "writing":"AI가 답했어요.",
        "drawing":"AI가 그린 결과"
    }
    const handleSelectContent = (content) => {
        setSelectedContent(content);
    };
    const handleClose = () => {
        setShowViewAllModal(false);
    };

    return (
        <>
            <div className="result-container">
                <h3 className="result-tit">{result_title[type]}</h3>
                {type==="writing" && <div className="result-box writing-result"><RenderTextWithBreaks text={result} /></div>}
                {type==="drawing" && (
                    <>
                        <div className="result-box draw-result">
                            <img src={result}></img>
                        </div>
                        <p className="commercial-useage">
                            * 이 그림은 AI가 그린것으로 상업적으로 사용하면
                            안돼요~!
                        </p>
                    </>
                )}
                <div className="result-btn-container">
                    <div className="btn wide-view-btn" onClick={() => setShowViewAllModal(true)} >크게보기</div>
                    <div>
                        {showViewAllModal && <ViewAllModal type={type} resultList={[...resultList].reverse()} onSelectContent={handleSelectContent} onClose={handleClose} />}
                    </div>
                    <div className="btn save-btn" onClick={onResult}>저장하기</div>
                </div>
            </div>
        </>
    );
};

export default Result;
