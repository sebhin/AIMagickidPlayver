import React, { useEffect, useState } from 'react';
import '../styles/TeacherLogin.scss';
import { useNavigate } from 'react-router-dom';

// 임시 로그인 아이디, 비밀번호
const temp_id = 'teacher';
const temp_password = '12345';

const TeacherLogin = () => {
    const navigate = useNavigate();
    const [logoImage, setLogoImage] = useState();
    const [id, setId] = useState('');
    const [password, setPassword] = useState('');

    // 로그인 처리
    // 로그인 상태 로컬스토리지에 저장함
    const handleLogin = (e) => {
        e.preventDefault();
        if (id === temp_id && password === temp_password) {
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('isTeacher', 'true');
            // localStorage.setItem('userID', 'true');
            navigate('/teacher-main');
        } else {
            alert('잘못된 아이디 또는 비밀번호입니다.');
        }
    };

    // 랜덤 로고 이미지
    const logos = [
        '/images/logo-6.svg',
        '/images/logo-5.svg',
        '/images/logo-3.svg',
    ];

    useEffect(() => {
        const randomIndex = Math.floor(Math.random() * logos.length);
        setLogoImage(logos[randomIndex]);
    }, []);

    const handleHomeClick = () => {
        navigate('/');
    };

    return (
        <>
            <div
                id="wrap"
                className="teacher-login-wrap"
            >
                <div className="inner">
                    <h1
                        className="logo"
                        onClick={handleHomeClick}
                    >
                        <img
                            src={logoImage}
                            alt="logo"
                        />
                    </h1>
                    <h3>선생님 로그인</h3>
                    <form
                        className="teacher-form"
                        onSubmit={handleLogin}
                    >
                        <input
                            type="text"
                            placeholder="아이디를 입력하세요"
                            value={id}
                            onChange={(e) => setId(e.target.value)}
                        />
                        <input
                            type="password"
                            placeholder="비밀번호를 입력하세요"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        <button className="btn login-btn">로그인</button>
                    </form>
                </div>
            </div>
        </>
    );
};

export default TeacherLogin;
