import React from 'react';
import { useParams } from 'react-router-dom';
import '../styles/Work.scss';
import Navigation from '../components/Navigation';
import WorkTabs from '../components/WorkTabs';

const Work = () => {
    const USER_ID = localStorage.getItem('userID');
    const USER_NAME = localStorage.getItem('userName');
    const { pageType } = useParams();

    // useEffect(() => {
    //     selectRandomImage();
    //     callGreationListAPI();
        
    // }, [pageType]);
    
    return (
        <>
            <section className="contents">
                <div className="left-contents">
                    <Navigation />
                </div>
                <div className="right-contents">
                    <div className="inner">
                        
                        {pageType==="school" && (
                            <>
                            <h3 className="tit">
                                <em className="blue-bold">{USER_NAME}</em> 님의 학교 전체의 멋진 작품들이에요!
                            </h3>
                            <WorkTabs page_type={pageType}/>
                            </>
                        )}
                        {pageType==="my" && (
                            <> 
                            <h3 className="tit">
                                <em className="blue-bold">{USER_NAME}</em> 님의 멋진 작품들이에요!
                            </h3>
                            <WorkTabs page_type={pageType}/>
                            </>
                        )}
                        
                    </div>
                </div>
            </section>
        </>
    );
};

export default Work;
