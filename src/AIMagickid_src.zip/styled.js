import { createGlobalStyle } from 'styled-components';
import reset from 'styled-reset';
import './fonts/font.css';

export const GlobalStyles = createGlobalStyle`
    ${reset}

    *{ box-sizing:border-box; font-family: 'NEXONLv1Gothic';}
    a{ text-decoration: none; color:initial;}
    body{font-family: 'NEXONLv1Gothic'; letter-spacing: -1px; word-break: keep-all; color: initial; }
    img{ display:block; width:100%; }
    .inner{width:1248px; margin:0 auto;}
    .tit{color:#111111; font-size:40px; font-weight:600;}
    .blue-bold{font-weight:bold; color:#134388;}
    .flex{display:flex; align-items:center; justify-content:space-between;}
    .btn{padding:10px; border-radius:4px;}

    :root{
        --bs-white: #ffffff;
        --bs-blue-primary: #134388;
        --bs-blue-hovered: #0c3064;
        --bs-blue-secondary: #518AD7;
        --bs-font-color: #111111;
        --bs-text-sub: #929292;
        --is-border: 1px solid #dddddd;
        --bs-bg-blue: #EEF3FE;
        --bs-bg-blue-light: #F7F8FA;
        --bs-nav-on: #CDE1FF;
    }

`;
